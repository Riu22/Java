/*12- Fes un programa que resti els números 11101101 (bin) i 85 (decimal) */
public class exercici12 {
    public static void main(String[] args) {
        int a = 0b11101101; 
        int b = 85;         
        int c = a + b;     
        System.out.println(c); 
    }
}
