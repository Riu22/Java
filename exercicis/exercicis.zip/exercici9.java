/*  9- Escriu un programa que efectui una operació bit a bit AND amb els números hexadecimals EE7A
i CAF3 */
public class exercici9{
    public static void main(String[] args) {
        int a = 0xEE7A;
        int b = 0xCAF3;
        int c = a & b ;
        System.out.println(c);
    }
    
}
