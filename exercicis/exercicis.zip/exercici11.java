/*11- Fes un programa que sumi els números 2EF (hex) i 123 (oct) */
public class exercici11 {
    public static void main(String[]arg){
        int a = 0x2EF;
        int b = 0123;
        int c = a + b;
        System.out.println(c);

    }
    
}
