/*  15- Fes un programa que escrigui “Hello” i a continuació el vostre nom (a la mateixa línia) */
public class exercici15 {
    public static void main(String[]arg){
        System.out.println("hola " + "Jaume");
    }
}
